package com.wli.tictactoe.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * This class is core database of the application.  
 *
 */

public class MyDBHelper
{
	
	// Database properties 
	private static final String DATABASE_NAME = "TicTacToe.sqlite";
	private static final String DATABASE_TABLE_PLAYER = "PlayerInfo";
	private static final int DATABASE_VERSION = 2;
	
	// User Table properties
	public static final String PLAYER_NAME = "sPlayerName";
	public static final String PLAYER1_DEVICE = "sPlayer1Device";
	public static final String PLAYER2_DEVICE = "sPlayer2Device";
	public static final String PLAYED = "sPLayed";
	public static final String WON = "sWon";
	public static final String LOST = "sLost";
	public static final String DRAWN = "sDrawn";
	
	
	// Create Script
	private static final String DATABASE_CREATE_PLAYER = "CREATE TABLE IF NOT EXISTS " + DATABASE_TABLE_PLAYER + "( " + PLAYER_NAME + " TEXT, " + PLAYER1_DEVICE + " TEXT, " + PLAYER2_DEVICE + " TEXT, " + PLAYED + " TEXT, " + WON + " TEXT, " + LOST + " TEXT, " + DRAWN + " TEXT " + " );";
	
	static final String TAG = "TicTacToe-MyDBHelper";
	
	private final Context context;
	
	private DatabaseHelper DBHelper;
	public static SQLiteDatabase db;
	
	public MyDBHelper(Context ctx)
	{
		this.context = ctx;
		
		DBHelper = new DatabaseHelper(context);
	}
	
	private static class DatabaseHelper extends SQLiteOpenHelper
	{
		DatabaseHelper(Context context)
		{
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			
		}
		
		@Override
		public void onCreate(SQLiteDatabase db)
		{
			db.execSQL(DATABASE_CREATE_PLAYER);
		}
		
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
		{
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_PLAYER);
			onCreate(db);
		}
	}
	
	//---opens the database---
	public MyDBHelper open() throws SQLException
	{
		db = DBHelper.getWritableDatabase();
		return this;
	}
	
	//---closes the database---    
	public void close()
	{
		if (db != null)
			db.close();
		if (DBHelper != null)
			DBHelper.close();
	}
	
	//---insert settings into the database---
	public long insertPlayer(String p_Player_Name,String p_Player1_Device,String p_Player2_Device,String p_Played,String p_Won,String p_Lost,String p_Drawn)
	{
		
		ContentValues m_initialValues = new ContentValues();
		m_initialValues.put(PLAYER_NAME, p_Player_Name);
		m_initialValues.put(PLAYER1_DEVICE, p_Player1_Device);
		m_initialValues.put(PLAYER2_DEVICE, p_Player2_Device);
		m_initialValues.put(PLAYED, p_Played);
		m_initialValues.put(WON, p_Won);
		m_initialValues.put(LOST, p_Lost);
		m_initialValues.put(DRAWN, p_Drawn);
		
		return db.insert(DATABASE_TABLE_PLAYER, null, m_initialValues);
	}
	/**
	 * This method updates the score of player.
	 * 
	 * @param p_Player_Name
	 * @param p_Player1_Device
	 * @param p_Player2_Device
	 * @param p_Played
	 * @param p_Won
	 * @param p_Lost
	 * @param p_Drawn
	 * @return updated rows.
	 */
	public long updatePlayer(String p_Player_Name,String p_Player1_Device,String p_Player2_Device,String p_Played,String p_Won,String p_Lost,String p_Drawn)
	{
		
		ContentValues m_initialValues = new ContentValues();
		m_initialValues.put(PLAYER_NAME, p_Player_Name);
		m_initialValues.put(PLAYER1_DEVICE, p_Player1_Device);
		m_initialValues.put(PLAYER2_DEVICE, p_Player2_Device);
		m_initialValues.put(PLAYED, p_Played);
		m_initialValues.put(WON, p_Won);
		m_initialValues.put(LOST, p_Lost);
		m_initialValues.put(DRAWN, p_Drawn);
		
		return db.update(DATABASE_TABLE_PLAYER, m_initialValues,"sPlayerName=? AND sPlayer1Device=? AND sPlayer2Device=?",new String[] {p_Player_Name, p_Player1_Device, p_Player2_Device });
	}
	
	public long updatePlayerName(String p_Player_Name, String p_Old_Name)
	{
		
		ContentValues m_initialValues = new ContentValues();
		m_initialValues.put(PLAYER_NAME, p_Player_Name);
		
		return db.update(DATABASE_TABLE_PLAYER, m_initialValues,"sPlayerName=? ",new String[] {p_Old_Name});
	}
	
	//---deletes Players---
	public boolean deletePlayer()
	{
		return db.delete(DATABASE_TABLE_PLAYER, null, null) > 0;
	}
	
	//---
	/**
	 * retrieves UserList---
	 * 
	 * @param p_UserID
	 *       the user's userID 
	 * 
	 * @param p_AvailableCredits
	 * 		  here is the AvailableCredits for the 
	 * @return
	 */
	public Cursor getList(String p_Player_Name,String p_Player1_Device, String p_Player2_Device)
	{
		String[] DataFields = new String[] { PLAYED,WON,LOST,DRAWN,PLAYER_NAME,PLAYER1_DEVICE,PLAYER2_DEVICE };
		return db.query(DATABASE_TABLE_PLAYER, DataFields, "sPlayer1Device=? AND sPlayer2Device=?" , new String[] {p_Player1_Device, p_Player2_Device }, null, null, null);
	}
	
	public Cursor getPlayerName()
	{
		return db.query(DATABASE_TABLE_PLAYER, new String[] {PLAYER_NAME}, null, null, null, null, null);
	}
	
}
