package com.wli.tictactoe.application;

import com.wli.tictactoe.activities.R;

/**
 * This class is having constants, which is common for other classes. 
 *
 */

public class TicTacToeConstants
{
	public static int THEME = R.style.Theme;
	public static int CROSSP1 = R.drawable.cross1p1;
	public static int ZEROP1 = R.drawable.zero1p1;
	public static int CROSSP2 = R.drawable.cross1p2;
	public static int ZEROP2 = R.drawable.zero1p2;
	public static boolean SOUND = true;
	public static int SCORE_BACK = R.drawable.score_back;

}
