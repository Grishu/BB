/**
 *	Project Name   :   Tic Tac Toe
 *  Class Name     :   TicTacToeApp
 *  Description    :   Activity for manage crashes
 *  Author         :   weblineIndia
 *  Creation Date  :   
 *  Modify Date    :   
 */
package com.wli.tictactoe.application;

import org.acra.ACRA;
import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;

import android.app.Application;

import com.wli.tictactoe.activities.R;

@ReportsCrashes(formKey = "dE9rLXQ5VGRkX19sYkNXeWNsT3Q3WUE6MQ", mode = ReportingInteractionMode.NOTIFICATION, resToastText = R.string.crash_toast_text, resNotifTickerText = R.string.crash_notif_ticker_text, resNotifTitle = R.string.crash_notif_title, resNotifText = R.string.crash_notif_text, resDialogText = R.string.crash_dialog_text, resDialogCommentPrompt = R.string.crash_dialog_comment_prompt)
public class TicTacToeApp extends Application
{
	@Override
	public void onCreate()
	{		
		ACRA.init(this);
		super.onCreate();
	}	
}