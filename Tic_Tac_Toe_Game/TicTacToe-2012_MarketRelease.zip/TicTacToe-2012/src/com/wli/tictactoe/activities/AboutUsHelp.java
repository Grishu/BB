package com.wli.tictactoe.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import com.wli.tictactoe.application.TicTacToeConstants;

/**
 * This class is common for About Us and Help activity.
 *
 */

public class AboutUsHelp extends Activity
{
	WebView mWebview;
	Intent mIntent;
	String mPage;
	TextView mHeading;
	Button mBack;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.aboutus_help);
		
		mWebview = (WebView) findViewById(R.id.webView1);
		mHeading = (TextView) findViewById(R.id.rltvaboutus_help);
		mBack = (Button)findViewById(R.id.rlabtushelpbtnback);
		
		mIntent = getIntent();
		mPage = mIntent.getStringExtra("page");
		
		Typeface face=Typeface.createFromAsset(getAssets(), "AACHENN_0.TTF"); 
		mHeading.setTextSize(30);
		mHeading.setTypeface(face);
		
		if (mPage.contains("about"))
		
			mHeading.setText("About Us");
		else
			
			mHeading.setText("Help");
		
		try
		{
			WebSettings m_set= mWebview.getSettings();
			if(m_set.supportZoom())
			m_set.setBuiltInZoomControls(true);
			mWebview.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
			mWebview.loadUrl("file:///android_asset/"+mPage);
			
		}
		catch (Exception e)
		{
		}
		
		mBack.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				finish();
			}
		});
		
}

	/**
	 * This method plays sound for button click.
	 */
	public void playButton()
	{
		MediaPlayer m = new MediaPlayer();
		try
		{
			AssetFileDescriptor descriptor =
					AboutUsHelp.this.getAssets().openFd("btnClick.caf");
			m.setDataSource(descriptor.getFileDescriptor(),
					descriptor.getStartOffset(), descriptor.getLength());
			descriptor.close();
			m.prepare();
			m.start();
		}
		catch (Exception e)
		{
			// handle error here..
			Log.e("Error in Sound", "" + e);
		}
	}
	

	/**
	 *  Method Name	:   openWebURL
	 *  Description :   Open url link on web
	 *  Parameter   :   1. inURL - url link 
	 *  Return      :   
	 */
	public void openWebURL( String inURL )
	{
	    Intent browse = new Intent( Intent.ACTION_VIEW , Uri.parse( inURL ) );
	    startActivity( browse );
	}
}
