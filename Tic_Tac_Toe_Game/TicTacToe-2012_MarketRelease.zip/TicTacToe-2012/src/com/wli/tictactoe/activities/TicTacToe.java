package com.wli.tictactoe.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.SlidingDrawer;
import android.widget.SlidingDrawer.OnDrawerCloseListener;
import android.widget.SlidingDrawer.OnDrawerOpenListener;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.wli.tictactoe.application.BluetoothChatService;
import com.wli.tictactoe.application.TicTacToeConstants;
import com.wli.tictactoe.database.MyDBHelper;

/**
 * This is the main Activity that displays the Game Board.
 */
public class TicTacToe extends Activity implements OnDrawerOpenListener,
		OnDrawerCloseListener
{

	// Message types sent from the BluetoothChatService Handler
	public static final int MESSAGE_STATE_CHANGE = 1;
	public static final int MESSAGE_READ = 2;
	public static final int MESSAGE_WRITE = 3;
	public static final int MESSAGE_DEVICE_NAME = 4;
	public static final int MESSAGE_TOAST = 5;
	public static final int MESSAGE_FIRST = 6;
	
	// Key names received from the BluetoothChatService Handler
	public static final String DEVICE_NAME = "device_name";
	public static final String TOAST = "toast";
	
	// Intent request codes
	private static final int REQUEST_CONNECT_DEVICE_SECURE = 1;
	private static final int REQUEST_CONNECT_DEVICE_INSECURE = 2;
	private static final int REQUEST_ENABLE_BT = 3;
	
	// Layout Views
	private Button mClicked, mBack;
	private TextView mTurns, mWonScore, mLostScore, mPlayedScore, mDrawnScore,
			mPlayerName;
	private RelativeLayout mrlScore;
	
	private SlidingDrawer slidingDrawer;
	
	private MyDBHelper mhelper;
	private Cursor mCursor;
	
	// Name of the connected device
	private String mConnectedDeviceName = null;
	
	// String buffer for outgoing messages
	private StringBuffer mOutStringBuffer;
	// Local Bluetooth adapter
	private BluetoothAdapter mBluetoothAdapter = null;
	// Member object for the chat services
	private BluetoothChatService mChatService = null;
	private TableLayout layout;
	private String mCallingDevice, mwinnerData, sPlayerName;
	
	AlertDialog dialog;
	public ProgressDialog progressDialog;
	
	static boolean flag = false;

	Intent mintent;
	static boolean mWinnerFlag = false, mActivityFirst = true, mConnectedFlag = false, mresetFlag = false, mAckflag = false;
	static int ScoreWon, ScoreLost, ScorePlayed, ScoreDrawn;
	String[] mArray = { " ", " ", " ", " ", " ", " ", " ", " ", " " };
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		setTheme(TicTacToeConstants.THEME);
		// Set up the window layout
		setContentView(R.layout.tictactoe);
		mTurns = (TextView) findViewById(R.id.textView2);
		mTurns.setText(" ");
		// Get local Bluetooth adapter
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		
		// If the adapter is null, then Bluetooth is not supported
		if (mBluetoothAdapter == null)
		{
			Toast.makeText(this, "Bluetooth is not available",
					Toast.LENGTH_LONG).show();
			finish();
			return;
		}
		layout = (TableLayout) findViewById(R.id.tableLayout1);
		
		mPlayedScore = (TextView) findViewById(R.id.rltvPlayedScore);
		mWonScore = (TextView) findViewById(R.id.rltvWonScore);
		mLostScore = (TextView) findViewById(R.id.rltvLostScore);
		mDrawnScore = (TextView) findViewById(R.id.rltvDrawnScore);
		
		mPlayerName = (TextView) findViewById(R.id.llplayername);
		mBack = (Button)findViewById(R.id.rltictacbtnback);
		
		mrlScore = (RelativeLayout) findViewById(R.id.rlScore);
		
		slidingDrawer = (SlidingDrawer) findViewById(R.id.slidingDrawer);
		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
		
		float m_scale = this.getResources().getDisplayMetrics().density;
		
		if(m_scale<=1)
			params.setMargins(0, 150, 0, 0);
		else if(m_scale<1.5)
			params.setMargins(0, 200, 0, 0);
		else if(m_scale==1.5)
			params.setMargins(0, 300, 0, 0);
		else
			params.setMargins(0, 500, 0, 0);
		slidingDrawer.setLayoutParams(params);
		
		mintent = getIntent();
		mhelper = new MyDBHelper(TicTacToe.this);
		mhelper.open();
		
		sPlayerName = mintent.getStringExtra("sPlayerName");
		
		mPlayerName.setText(sPlayerName);
		
		mBack.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				dialog =
						new AlertDialog.Builder(TicTacToe.this)
								.create();
				dialog.setTitle("Tic Tac Toe");
				dialog.setMessage("Want to quit the game?");
				
				dialog.setButton(Dialog.BUTTON_POSITIVE,"OK",
						new DialogInterface.OnClickListener(){
							
							@Override
							public void onClick(DialogInterface dialog, int which)
							{
								sendMessage("finish");
								
								mPlayedScore.setText("" + 0);
								mWonScore.setText("" + 0);
								mLostScore.setText("" + 0);
								mDrawnScore.setText("" + 0);
								makeClearButtons(layout);
								ScorePlayed = 0;
								ScoreWon = 0;
								ScoreLost = 0;
								ScoreDrawn = 0;
								finish();

								dialog.dismiss();
							}
						});
				dialog.setButton(Dialog.BUTTON_NEGATIVE,"CANCEL",
						new DialogInterface.OnClickListener(){
							
							@Override
							public void onClick(DialogInterface dialog, int which)
							{
								dialog.dismiss();
							}
						});
				if(mConnectedFlag)
				{	
					dialog.show();
				}
				else
					finish();
			}
		});
		
		// Listen for open event
		slidingDrawer.setOnDrawerOpenListener(this);
		
		// Listen for close event
		slidingDrawer.setOnDrawerCloseListener(this);
		
	}
	/**
	 * This method resets the score.
	 * @param view
	 */
	public void resetScore(View v)
	{
		dialog = new AlertDialog.Builder(TicTacToe.this).create();
		dialog.setTitle("Tic Tac Toe");
		dialog.setMessage("All Scores will be set to 0.");
		
		dialog.setButton(Dialog.BUTTON_POSITIVE, "OK",
				new DialogInterface.OnClickListener(){
					
					@Override
					public void onClick(DialogInterface dialog, int which)
					{
						ScorePlayed = 0;
						ScoreWon = 0;
						ScoreLost = 0;
						ScoreDrawn = 0;
						
						if (mConnectedDeviceName == null)
						{
							Toast.makeText(TicTacToe.this,
									"You are not connected with any device.",
									Toast.LENGTH_SHORT).show();
							return;
						}
						mhelper.updatePlayer(sPlayerName,
								mBluetoothAdapter.getName(),
								mConnectedDeviceName, "" + ScorePlayed, ""
										+ ScoreWon, "" + ScoreLost, ""
										+ ScoreDrawn);
						
						mPlayedScore.setText("" + ScorePlayed);
						mWonScore.setText("" + ScoreWon);
						mLostScore.setText("" + ScoreLost);
						mDrawnScore.setText("" + ScoreDrawn);
						
						sendMessage("Reset");
					}
				});
		dialog.setButton(Dialog.BUTTON_NEGATIVE, "CANCEL",
				new DialogInterface.OnClickListener(){
					
					@Override
					public void onClick(DialogInterface dialog, int which)
					{
						dialog.dismiss();
					}
				});
		dialog.show();
	}
	
	public void onDrawerOpened()
	{
		// Hide listview
		mrlScore.setVisibility(View.VISIBLE);
		
	}
	
	public void onDrawerClosed()
	{
		// now make it visible again
		mrlScore.setVisibility(View.GONE);
	}
	/**
	 * This method checks weather bluetooth is discoverable or not?
	 */
	public void checkDiscoverable()
	{
		// Check Discoverable
		
		if (mBluetoothAdapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE)
		{
			Intent discoverableIntent =
					new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
			discoverableIntent.putExtra(
					BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 500);
			startActivity(discoverableIntent);
		}
	}
	
	@Override
	public void onStart()
	{
		super.onStart();
		
		// If BT is not on, request that it be enabled.
		// setupChat() will then be called during onActivityResult
		if (!mBluetoothAdapter.isEnabled())
		{
			Intent enableIntent =
					new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
			startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
			// Otherwise, setup the chat session
		}
		else
		{
			// ensureDiscoverable();
			if (mChatService == null)
				setupChat();
		}
	}
	
	@Override
	public synchronized void onResume()
	{
		super.onResume();
		
		// Performing this check in onResume() covers the case in which BT was
		// not enabled during onStart(), so we were paused to enable it...
		// onResume() will be called when ACTION_REQUEST_ENABLE activity
		// returns.
		if (mChatService != null)
		{
			// Only if the state is STATE_NONE, do we know that we haven't
			// started already
			if (mChatService.getState() == BluetoothChatService.STATE_NONE)
			{
				// Start the Bluetooth chat services
				mChatService.start();
					if (mChatService.getState() != BluetoothChatService.STATE_CONNECTED)
					{
						dialog = new AlertDialog.Builder(TicTacToe.this).create();
						dialog.setTitle("Tic Tac Toe");
						dialog.setMessage("You are not connected to any device. Please connect to a single device.");
						
						dialog.setButton("OK", new DialogInterface.OnClickListener(){
							
							@Override
							public void onClick(DialogInterface dialog, int which)
							{
								dialog.dismiss();
								// Launch the DeviceListActivity to see devices and do scan
								Intent serverIntent = new Intent(TicTacToe.this, DeviceListActivity.class);
								startActivityForResult(serverIntent,
										REQUEST_CONNECT_DEVICE_SECURE);
							}
						});
						dialog.show();
						
						return;
					}
			}
		}
	}
	
	/**
	 * When the button is clicked.
	 * @param view
	 */
	
	public void onButtonPressed(View v)
	{
		Button button = (Button) v;
		String buttonTag = (String) button.getTag();
		
		int buttonId = Integer.parseInt(buttonTag);

		/**
		 * This is commented as in future if we want to play with selected row or column
		 */
		/*		int posRow = buttonId / 3;
		int posCol = buttonId % 3;*/
		
		if (mChatService.getState() != BluetoothChatService.STATE_CONNECTED)
		{

			
			dialog = new AlertDialog.Builder(TicTacToe.this).create();
			dialog.setTitle("Tic Tac Toe");
			dialog.setMessage("You are not connected to any device. Please connect to a single device, by pressing menu button.");
			
			dialog.setButton("OK", new DialogInterface.OnClickListener(){
				
				@Override
				public void onClick(DialogInterface dialog, int which)
				{
					dialog.dismiss();
				}
			});
			dialog.show();
			return;
		}
		
		if(TicTacToeConstants.SOUND)
			playButton();
		/**
		 * Who initiates the game according to that Turn is decided.
		 * 
		 * --> Starts
		 */
				if (mBluetoothAdapter.getName().equalsIgnoreCase(mCallingDevice))
				{
					sendMessage(buttonTag + "X");
					mArray[buttonId] = "X";
					button.setBackgroundResource(TicTacToeConstants.CROSSP1);
					button.setClickable(false);
					disableButton(layout);
					mTurns.setText("Opponent's Turn.");
					
				}
				else
				{
					sendMessage(buttonTag + "0");
					mArray[buttonId] = "0";
					button.setBackgroundResource(TicTacToeConstants.ZEROP1);
					button.setClickable(false);
					disableButton(layout);
					mTurns.setText("Opponent's Turn.");
					
				}
		/**
		 *  ends <---
		 */
		String m1, m2, m3, m4, m5, m6, m7, m8, m9;
		
		m1 = mArray[0];
		m2 = mArray[1];
		m3 = mArray[2];
		
		m4 = mArray[3];
		m5 = mArray[4];
		m6 = mArray[5];
		
		m7 = mArray[6];
		m8 = mArray[7];
		m9 = mArray[8];
		
		// to check a winner
		
		mwinnerData = "continue";
		
		/**
		 * This is to check all the 3 possibles are clicked or not.
		 * 
		 * ---> Starts
		 */
		
		if ((m1.equals(m2)) && (m2.equals(m3)))
		{
			mwinnerData = m2;
			if (!mwinnerData.equals(" "))
			{
				mwinnerData = m2;
				winnerLoser(mwinnerData);
			}
		}
		if ((m4.equals(m5)) && (m5.equals(m6)))
		{
			mwinnerData = m4;
			if (!mwinnerData.equals(" "))
			{
				mwinnerData = m5;
				winnerLoser(mwinnerData);
			}
		}
		if ((m7.equals(m8)) && (m8.equals(m9)))
		{
			mwinnerData = m7;
			if (!mwinnerData.equals(" "))
			{
				mwinnerData = m8;
				winnerLoser(mwinnerData);
			}
		}
		if ((m1.equals(m4)) && (m4.equals(m7)))
		{
			mwinnerData = m4;
			if (!mwinnerData.equals(" "))
			{
				mwinnerData = m4;
				winnerLoser(mwinnerData);
			}
		}
		if ((m2.equals(m5)) && (m5.equals(m8)))
		{
			mwinnerData = m2;
			if (!mwinnerData.equals(" "))
			{
				mwinnerData = m5;
				winnerLoser(mwinnerData);
			}
		}
		if ((m3.equals(m6)) && (m6.equals(m9)))
		{
			mwinnerData = m3;
			if (!mwinnerData.equals(" "))
			{
				mwinnerData = m6;
				winnerLoser(mwinnerData);
			}
		}
		if ((m1.equals(m5)) && (m5.equals(m9)))
		{
			mwinnerData = m1;
			if (!mwinnerData.equals(" "))
			{
				mwinnerData = m5;
				winnerLoser(mwinnerData);
			}
		}
		if ((m3.equals(m5)) && (m5.equals(m7)))
		{
			mwinnerData = m3;
			if (!mwinnerData.equals(" "))
			{
				mwinnerData = m5;
				winnerLoser(mwinnerData);
			}
		}
		
		/**
		 * ends <---
		 */
		
		/**
		 * This is to check if tie occurs or not.
		 */
		if (!m1.contains(" ") && !m2.contains(" ") && !m3.contains(" ")
				&& !m4.contains(" ") && !m5.contains(" ") && !m6.contains(" ")
				&& !m7.contains(" ") && !m8.contains(" ") && !m9.contains(" ")
				&& mwinnerData.equals("continue"))
		{
			
			sendMessage("Tie.");
			dialog = new AlertDialog.Builder(TicTacToe.this).create();
			dialog.setTitle("Tic Tac Toe");
			dialog.setMessage("Tie. Want to Continue?");
			dialog.setCancelable(false);
			
			dialog.setButton(Dialog.BUTTON_POSITIVE, "Yes",
					new DialogInterface.OnClickListener(){
						
						@Override
						public void onClick(DialogInterface dialog, int which)
						{
							sendMessage("Ack");
							
							for (int i = 0; i < 9; i++)
								mArray[i] = " ";
							Toast.makeText(TicTacToe.this, "Waiting for acknowledgement.", Toast.LENGTH_SHORT).show();
						}
					});
			dialog.setButton(Dialog.BUTTON_NEGATIVE, "No",
					new DialogInterface.OnClickListener(){
						
						@Override
						public void onClick(DialogInterface dialog, int which)
						{
							TicTacToe.this.sendMessage("finish");
							finish();
						}
					});
			dialog.show();
			if(TicTacToeConstants.SOUND)
				playTie();
			return;
		}
	}
	
	/**
	 * This method plays sound for button click.
	 */
	
	public void playButton()
	{
		MediaPlayer m = new MediaPlayer();
		try
		{
			AssetFileDescriptor descriptor =
					TicTacToe.this.getAssets().openFd("btnClick.caf");
			m.setDataSource(descriptor.getFileDescriptor(),
					descriptor.getStartOffset(), descriptor.getLength());
			descriptor.close();
			m.prepare();
			m.start();
		}
		catch (Exception e)
		{
			// handle error here..
			Log.e("Error in Sound", "" + e);
		}
	}
	
	/**
	 * This method plays sound when tie occurs.
	 */
	
	public void playTie()
	{
		MediaPlayer m = new MediaPlayer();
		try
		{
			AssetFileDescriptor descriptor =
					TicTacToe.this.getAssets().openFd("winner.wav");
			m.setDataSource(descriptor.getFileDescriptor(),
					descriptor.getStartOffset(), descriptor.getLength());
			descriptor.close();
			m.prepare();
			m.start();
		}
		catch (Exception e)
		{
			// handle error here..
			Log.e("Error in Sound", "" + e);
		}
	}
	/**
	 * This method is to check winner or loser.
	 */
	private void winnerLoser(String mwinnerData)
	{
		if (mwinnerData.equals("X"))
		{
			dialog = new AlertDialog.Builder(TicTacToe.this).create();
			dialog.setTitle("Tic Tac Toe");
			dialog.setMessage("You Won Game. Want to Continue?");
			dialog.setCancelable(false);
			
			dialog.setButton(Dialog.BUTTON_POSITIVE, "Yes",
					new DialogInterface.OnClickListener(){
						
						@Override
						public void onClick(DialogInterface dialog, int which)
						{
							sendMessage("Ack");
							
							for (int i = 0; i < 9; i++)
								mArray[i] = " ";
							Toast.makeText(TicTacToe.this, "Waiting for acknowledgement.", Toast.LENGTH_SHORT).show();
						}
					});
			
			dialog.setButton(Dialog.BUTTON_NEGATIVE, "No",
					new DialogInterface.OnClickListener(){
						
						@Override
						public void onClick(DialogInterface dialog, int which)
						{
							TicTacToe.this.sendMessage("finish");
							finish();
						}
					});
			dialog.show();
			if (TicTacToeConstants.SOUND)
					playWinner();
			mWinnerFlag = true;
			
			sendMessage("You Lost Game. Want to Continue?");
			++ScoreWon;
			return;
			
		}
		if (mwinnerData.equals("0"))
		{
			dialog = new AlertDialog.Builder(TicTacToe.this).create();
			dialog.setTitle("Tic Tac Toe");
			dialog.setMessage("You Won Game. Want to Continue?");
			dialog.setCancelable(false);
			
			dialog.setButton(Dialog.BUTTON_POSITIVE, "Yes",
					new DialogInterface.OnClickListener(){
						
						@Override
						public void onClick(DialogInterface dialog, int which)
						{
							sendMessage("Ack");
							
							for (int i = 0; i < 9; i++)
								mArray[i] = " ";
							Toast.makeText(TicTacToe.this, "Waiting for acknowledgement.", Toast.LENGTH_SHORT).show();
						}
					});
			dialog.setButton(Dialog.BUTTON_NEGATIVE, "No",
					new DialogInterface.OnClickListener(){
						
						@Override
						public void onClick(DialogInterface dialog, int which)
						{
							TicTacToe.this.sendMessage("finish");
							finish();
						}
					});
			dialog.show();
			if (TicTacToeConstants.SOUND)
				playWinner();
			sendMessage("You Lost Game. Want to Continue?");
			++ScoreWon;
			mWinnerFlag = true;
			return;
		}
	}
	/**
	 * This method plays sound when user wons.
	 */
	private void playWinner()
	{
		MediaPlayer m = new MediaPlayer();
		try
		{
			AssetFileDescriptor descriptor =
					TicTacToe.this.getAssets().openFd("winner.wav");
			m.setDataSource(descriptor.getFileDescriptor(),
					descriptor.getStartOffset(), descriptor.getLength());
			descriptor.close();
			m.prepare();
			m.start();
		}
		catch (Exception e)
		{
			// handle error here..
			Log.e("Error in Sound", "" + e);
		}
	}

	/**
	 * This method clears and enables all the buttons.
	 * @param view
	 */
	
	public void makeClearEnableButtons(View view)
	{
		if (view instanceof TableLayout)
		{
			for (int i = 0; i < 3; i++)
			
			{
				TableRow row = (TableRow) ((ViewGroup) view).getChildAt(i);
				makeClearEnableButtons(row);
			}
		}
		if (view instanceof TableRow)
		{
			for (int i = 0; i < 3; i++)
			{
				Button mtemp = (Button) ((ViewGroup) view).getChildAt(i);
				mtemp.setEnabled(true);
				mtemp.setClickable(true);
				mtemp.setText(" ");
				mtemp.setBackgroundResource(R.drawable.themebtn);
			}
		}
	}
	
	/**
	 * This method clears all the buttons.
	 * @param view
	 */
	
	public void makeClearButtons(View view)
	{
		
		if (view instanceof TableLayout)
		{
			for (int i = 0; i < 3; i++)
			
			{
				TableRow row = (TableRow) ((ViewGroup) view).getChildAt(i);
				makeClearButtons(row);
			}
		}
		if (view instanceof TableRow)
		{
			for (int i = 0; i < 3; i++)
			{
				Button mtemp = (Button) ((ViewGroup) view).getChildAt(i);
				mtemp.setClickable(true);
				mtemp.setText(" ");
				mtemp.setBackgroundResource(R.drawable.themebtn);
			}
		}
	}
	/**
	 * This method disables all the buttons.
	 * @param view
	 */
	private void disableButton(View view)
	{
		if (view instanceof TableLayout)
		{
			for (int i = 0; i < 3; i++)
			
			{
				
				TableRow row = (TableRow) ((ViewGroup) view).getChildAt(i);
				disableButton(row);
			}
		}
		if (view instanceof TableRow)
		{
			for (int i = 0; i < 3; i++)
			{
				Button mtemp = (Button) ((ViewGroup) view).getChildAt(i);
				mtemp.setEnabled(false);
			}
		}
	}
	
	private void setupChat()
	{
		// Initialize the BluetoothChatService to perform bluetooth connections
		mChatService = new BluetoothChatService(this, mHandler);
		
		// Initialize the buffer for outgoing messages
		mOutStringBuffer = new StringBuffer("");
	}
	
	@Override
	public synchronized void onPause()
	{
		super.onPause();
	}
	
	@Override
	public void onStop()
	{
		super.onStop();
	}
	
	@Override
	public void onDestroy()
	{
		super.onDestroy();
		// Stop the Bluetooth chat services
		if (mChatService != null)
			mChatService.stop();

		if(mCursor!=null)
			mCursor.close();

		mBluetoothAdapter.disable();
		if(progressDialog!=null)
			progressDialog.dismiss();
	}
	
	private void ensureDiscoverable()
	{
		if (mBluetoothAdapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE)
		{
			Intent discoverableIntent =
					new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
			discoverableIntent.putExtra(
					BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 500);
			startActivity(discoverableIntent);
		}
	}
	
	boolean isActivityFinished()
	{
		return isFinishing();
	}
	
	/**
	 * Sends a message.
	 * 
	 * @param message
	 *            A string of text to send.
	 */
	public void sendMessage(String message)
	{
		// Check that we're actually connected before trying anything
		
		if (mChatService.getState() != BluetoothChatService.STATE_CONNECTED)
		{
			dialog = new AlertDialog.Builder(TicTacToe.this).create();
			dialog.setTitle("Tic Tac Toe");
			dialog.setMessage("You are not connected to any device. Please connect to a single device.");
			
			dialog.setButton("OK", new DialogInterface.OnClickListener(){
				
				@Override
				public void onClick(DialogInterface dialog, int which)
				{
					dialog.dismiss();
				}
			});
			dialog.show();
			
			return;
		}
		
		// Check that there's actually something to send
		if (message.length() > 0)
		{
			// Get the message bytes and tell the BluetoothChatService to write
			byte[] send = message.getBytes();
			mChatService.write(send);
			
			// Reset out string buffer to zero and clear the edit text field
			mOutStringBuffer.setLength(0);
		}
	}
	/**
	 * This method is used to dismiss the progress dialog.
	 */
	public void dismissDialog()
	{
		if(progressDialog!=null)
			progressDialog.dismiss();
	}
	/**
	 * This method is used to show the progress dialog.
	 */
	public void show()
	{

		progressDialog = new ProgressDialog(TicTacToe.this);
		progressDialog.setTitle(getString(R.string.app_name));
		progressDialog.setMessage("Waiting for acknowledgment.");
		progressDialog.show();
	}
	
	// The Handler that gets information back from the BluetoothChatService
	private final Handler mHandler = new Handler(){
		
		@Override
		public void handleMessage(Message msg)
		{
			switch (msg.what)
				{
					case MESSAGE_STATE_CHANGE:
						switch (msg.arg1)
							{
								case BluetoothChatService.STATE_CONNECTED:
									break;
								case BluetoothChatService.STATE_CONNECTING:
									break;
								case BluetoothChatService.STATE_LISTEN:
								case BluetoothChatService.STATE_NONE:
									break;
							}
						break;
					case MESSAGE_WRITE:
						byte[] writeBuf = (byte[]) msg.obj;
						// construct a string from the buffer
						String writeMessage = new String(writeBuf);
						/**
						 * This checks weather write message contains Game or not.
						 */
						if (writeMessage.contains("Game"))
						{
							for (int i = 0; i < 9; i++)
								mArray[i] = " ";
							
							++ScorePlayed;
							mLostScore.setText("" + ScoreLost);
							mWonScore.setText("" + ScoreWon);
							mPlayedScore.setText("" + ScorePlayed);
							mhelper.updatePlayer(sPlayerName,
									mBluetoothAdapter.getName(),
									mConnectedDeviceName, "" + ScorePlayed, ""
											+ ScoreWon, "" + ScoreLost, ""
											+ ScoreDrawn);
							
						}
						/**
						 * This checks weather write message contains Tie or not.
						 */
						if (writeMessage.contains("Tie"))
						{
							for (int i = 0; i < 9; i++)
								mArray[i] = " ";
							
							++ScorePlayed;
							mDrawnScore.setText("" + (++ScoreDrawn));
							mhelper.updatePlayer(sPlayerName,
									mBluetoothAdapter.getName(),
									mConnectedDeviceName, "" + ScorePlayed, ""
											+ ScoreWon, "" + ScoreLost, ""
											+ ScoreDrawn);
							mPlayedScore.setText("" + ScorePlayed);
						}
						
						mPlayedScore.setText("" + ScorePlayed);
						break;
					
					case MESSAGE_READ:
						byte[] readBuf = (byte[]) msg.obj;
						// construct a string from the valid bytes in the buffer
						String readMessage = new String(readBuf, 0, msg.arg1);
					
						if(readMessage.equals("finish"))
						{
							Toast.makeText(getApplicationContext(), "Game finished from another side.", Toast.LENGTH_SHORT).show();
							mChatService.stop();
						}
						else if(readMessage.equals("Ack"))
						{
							for (int i = 0; i < 9; i++)
								mArray[i] = " ";
							
							if (!mTurns.getText().toString()
									.contains("Opponent"))
								makeClearEnableButtons(layout);
							else
								makeClearButtons(layout);
							if(progressDialog!=null)
								progressDialog.dismiss();
							Toast.makeText(getApplicationContext(), "Game continued from other side.", Toast.LENGTH_SHORT).show();
						}
						else if (readMessage.equals("Reset"))
						{
							mresetFlag = true;
							
							dialog =
									new AlertDialog.Builder(TicTacToe.this)
											.create();
							dialog.setTitle("Tic Tac Toe");
							dialog.setMessage("Opponent reset Scores. All Scores will be set to 0.");
							dialog.setCancelable(false);
							
							dialog.setButton(Dialog.BUTTON_POSITIVE, "OK",
									new DialogInterface.OnClickListener(){
										
										@Override
										public void onClick(DialogInterface dialog, int which)
										{
											ScorePlayed = 0;
											ScoreWon = 0;
											ScoreLost = 0;
											ScoreDrawn = 0;
											
											mhelper.updatePlayer(sPlayerName,
													mBluetoothAdapter.getName(),
													mConnectedDeviceName, "" + ScorePlayed, ""
															+ ScoreWon, "" + ScoreLost, ""
															+ ScoreDrawn);
											
											mPlayedScore.setText(""
													+ ScorePlayed);
											mWonScore.setText("" + ScoreWon);
											mLostScore.setText("" + ScoreLost);
											mDrawnScore
													.setText("" + ScoreDrawn);
										}
									});
							dialog.show();
						}
						else if (readMessage.contains("Tie"))
						{
							++ScorePlayed;
							mPlayedScore.setText("" + ScorePlayed);
							++ScoreDrawn;
							mDrawnScore.setText("" + ScoreDrawn);
							
							mhelper.updatePlayer(sPlayerName,
									mBluetoothAdapter.getName(),
									mConnectedDeviceName, "" + ScorePlayed, ""
											+ ScoreWon, "" + ScoreLost, ""
											+ ScoreDrawn);
							
							dialog =
									new AlertDialog.Builder(TicTacToe.this)
											.create();
							dialog.setTitle("Tic Tac Toe");
							dialog.setMessage("Tie. Want to Continue?");
							dialog.setCancelable(false);
							
							dialog.setButton(Dialog.BUTTON_POSITIVE, "Yes",
									new DialogInterface.OnClickListener(){
										
										@Override
										public void onClick(DialogInterface dialog, int which)
										{
											TicTacToe.this.sendMessage("Ack");
											
											for (int i = 0; i < 9; i++)
												mArray[i] = " ";
											Toast.makeText(TicTacToe.this, "Waiting for acknowledgement.", Toast.LENGTH_SHORT).show();
											
										}
									});
							dialog.setButton(Dialog.BUTTON_NEGATIVE, "No",
									new DialogInterface.OnClickListener(){
										
										@Override
										public void onClick(DialogInterface dialog, int which)
										{
											TicTacToe.this.sendMessage("finish");
											finish();
										}
									});
							
							dialog.show();
							if(TicTacToeConstants.SOUND)
								playTie();
							mClicked.setClickable(false);
							
/*							Runnable mMyRunnable = new Runnable()
							{
							    @Override
							    public void run()
							    {*/
									disableButton(layout);
/*							    }
							 };
							 
							Handler myHandler = new Handler();
							myHandler.postDelayed(mMyRunnable, 500);*/
							mTurns.setText("Your Turn.");
							
						}
						else if (readMessage.contains("Game"))
						{
							++ScorePlayed;
							mPlayedScore.setText("" + ScorePlayed);
							
							mWonScore.setText("" + ScoreWon);
							mLostScore.setText("" + (++ScoreLost));
							
							mhelper.updatePlayer(sPlayerName,
									mBluetoothAdapter.getName(),
									mConnectedDeviceName, "" + ScorePlayed, ""
											+ ScoreWon, "" + ScoreLost, ""
											+ ScoreDrawn);
							
							dialog =
									new AlertDialog.Builder(TicTacToe.this)
											.create();
							dialog.setTitle("Tic Tac Toe");
							if(readMessage.substring(1).equalsIgnoreCase("X") || readMessage.substring(1).equals("0"))
								dialog.setMessage(readMessage.substring(1,readMessage.length()));
							else
								dialog.setMessage(readMessage);
							dialog.setCancelable(false);
							
							dialog.setButton(Dialog.BUTTON_POSITIVE, "Yes",
									new DialogInterface.OnClickListener(){
										
										@Override
										public void onClick(DialogInterface dialog, int which)
										{
											TicTacToe.this.sendMessage("Ack");
											
											for (int i = 0; i < 9; i++)
												mArray[i] = " ";
											
											Toast.makeText(TicTacToe.this, "Waiting for acknowledgement.", Toast.LENGTH_SHORT).show();
										}
									});
							dialog.setButton(Dialog.BUTTON_NEGATIVE, "No",
									new DialogInterface.OnClickListener(){
										
										@Override
										public void onClick(DialogInterface dialog, int which)
										{
											TicTacToe.this.sendMessage("finish");
											finish();
										}
									});
							dialog.show();
							if (TicTacToeConstants.SOUND)
								playLoser();
							mClicked.setClickable(false);
/*							Runnable mMyRunnable = new Runnable()
							{
							    @Override
							    public void run()
							    {*/
									disableButton(layout);
/*							    }
							 };
							 
							Handler myHandler = new Handler();
							myHandler.postDelayed(mMyRunnable, 500);*/
							mTurns.setText("Your Turn.");
						}
						else
						{							
							makeMove(readMessage);						
						}
						
						break;
					case MESSAGE_DEVICE_NAME:
						// save the connected device's name
						mConnectedDeviceName =
								msg.getData().getString(DEVICE_NAME);
						
						  Toast.makeText(getApplicationContext(),"Connected to " 
						  + mConnectedDeviceName,Toast.LENGTH_SHORT).show();
						  
						  mConnectedFlag = true;
						  dismissDialog();
						 
					
						mCursor =
								mhelper.getList(sPlayerName,
										mBluetoothAdapter.getName(),
										mConnectedDeviceName);
						if (mCursor != null)
						{
							if (mCursor.moveToFirst())
							{
								ScorePlayed =
										Integer.parseInt(mCursor.getString(0));
								ScoreWon =
										Integer.parseInt(mCursor.getString(1));
								ScoreLost =
										Integer.parseInt(mCursor.getString(2));
								ScoreDrawn =
										Integer.parseInt(mCursor.getString(3));
								
								mPlayedScore.setText("" + mCursor.getString(0));
								mWonScore.setText("" + mCursor.getString(1));
								mLostScore.setText("" + mCursor.getString(2));
								mDrawnScore.setText("" + mCursor.getString(3));
							}
							else
							{
								ScorePlayed = 0;
								ScoreWon = 0;
								ScoreLost = 0;
								ScoreDrawn = 0;
								
								long id =
										mhelper.insertPlayer(sPlayerName,
												mBluetoothAdapter.getName(),
												mConnectedDeviceName, ""
														+ ScorePlayed, ""
														+ ScoreWon, ""
														+ ScoreLost, ""
														+ ScoreDrawn);
								Toast.makeText(getApplicationContext(),
										"Rows Inserted:" + id,  Toast.LENGTH_SHORT ).show();
							}
							
						}
						else
						{
							ScorePlayed = 0;
							ScoreWon = 0;
							ScoreLost = 0;
							ScoreDrawn = 0;
							
							long id =
									mhelper.insertPlayer(sPlayerName,
											mBluetoothAdapter.getName(),
											mConnectedDeviceName, ""
													+ ScorePlayed, ""
													+ ScoreWon, "" + ScoreLost,
											"" + ScoreDrawn);
							Toast.makeText(getApplicationContext(),
									"Rows Inserted:" + id,  Toast.LENGTH_SHORT ).show();
						}
						
						// This logic will block opponet's layout when first connection
						// request is initiated.
						
						if (mConnectedDeviceName.contains("tic_tac"))
						{
							if (!mTurns.getText().toString().contains("Turn"))
							{
								mTurns.setText("Opponent's Turn.");
								disableButton(layout);
								DeviceListActivity.closeList();
							}
						}
						break;
					case MESSAGE_TOAST:
						Toast.makeText(getApplicationContext(),
								msg.getData().getString(TOAST),
								Toast.LENGTH_SHORT).show();
						if (msg.getData().getString(TOAST).contains("Unable"))
						{
							mTurns.setText(" ");
							mCallingDevice = null;
							mConnectedFlag = false;
							dismissDialog();
						}
						if (msg.getData().getString(TOAST)
								.contains("connection was lost"))
						{
							mTurns.setText(" ");
							mConnectedFlag = false;
							ScorePlayed = 0;
							ScoreWon = 0;
							ScoreLost = 0;
							ScoreDrawn = 0;
							
							mArray[0] = " ";
							mArray[1] = " ";
							mArray[2] = " ";
							
							mArray[3] = " ";
							mArray[4] = " ";
							mArray[5] = " ";
							
							mArray[6] = " ";
							mArray[7] = " ";
							mArray[8] = " ";
							
							dialog =
									new AlertDialog.Builder(TicTacToe.this)
											.create();
							dialog.setTitle("Tic Tac Toe");
							dialog.setMessage("Device connection was lost from other side.");
							
							dialog.setButton("OK",
									new DialogInterface.OnClickListener(){
										
										@Override
										public void onClick(DialogInterface dialog, int which)
										{
											mPlayedScore.setText("" + 0);
											mWonScore.setText("" + 0);
											mLostScore.setText("" + 0);
											mDrawnScore.setText("" + 0);
											makeClearButtons(layout);
											dialog.dismiss();
											finish();
											ScorePlayed = 0;
											ScoreWon = 0;
											ScoreLost = 0;
											ScoreDrawn = 0;
										}
									});
							
							if (!isActivityFinished())
								dialog.show();
							enableButton(layout);
						}
						
						break;
				}
		}
		


		private void makeMove(String readMessage)
		{
			int rowSize;
			TableRow row;
			
			rowSize = layout.getChildCount();
			try
			{
				row =
						(TableRow) layout.getChildAt(Integer
								.parseInt(readMessage.substring(0,
										1))
								/ rowSize);
				mClicked =
						(Button) row.getChildAt(Integer
								.parseInt(readMessage.substring(0,
										1))
								% rowSize);
				if (readMessage.substring(1).equals("X"))
					mClicked.setBackgroundResource(TicTacToeConstants.CROSSP2);
				else
					mClicked.setBackgroundResource(TicTacToeConstants.ZEROP2);
				
				if(TicTacToeConstants.SOUND)
				playButton();
				
				mArray[Integer.parseInt((String) mClicked.getTag())] =
						readMessage.substring(1);
				mClicked.setClickable(false);
				
				Runnable mMyRunnable = new Runnable()
				{
				    @Override
				    public void run()
				    {
						enableButton(layout);
				    }
				 };
				
				Handler myHandler = new Handler();
				myHandler.postDelayed(mMyRunnable, 500);
				mTurns.setText("Your Turn.");
			}
			catch (Exception e)
			{
				Log.e("Exception", "" + e);
			}
		}



		private void playLoser()
		{
			MediaPlayer m = new MediaPlayer();
			try
			{
				AssetFileDescriptor descriptor =
						TicTacToe.this.getAssets().openFd("failure.wav");
				m.setDataSource(descriptor.getFileDescriptor(),
						descriptor.getStartOffset(), descriptor.getLength());
				descriptor.close();
				m.prepare();
				m.start();
			}
			catch (Exception e)
			{
				// handle error here..
				Log.e("Error in Sound", "" + e);
			}
		}

		public void makeClearEnableButtons(View view)
		{
			
			if (view instanceof TableLayout)
			{
				for (int i = 0; i < 3; i++)
				
				{
					TableRow row = (TableRow) ((ViewGroup) view).getChildAt(i);
					makeClearEnableButtons(row);
				}
			}
			if (view instanceof TableRow)
			{
				for (int i = 0; i < 3; i++)
				{
					Button mtemp = (Button) ((ViewGroup) view).getChildAt(i);
					mtemp.setEnabled(true);
					mtemp.setClickable(true);
					mtemp.setText(" ");
					mtemp.setBackgroundResource(R.drawable.themebtn);
				}
			}
		}
		private void enableButton(View view)
		{
			
			if (view instanceof TableLayout)
			{
				for (int i = 0; i < 3; i++)
				
				{
					
					TableRow row = (TableRow) ((ViewGroup) view).getChildAt(i);
					enableButton(row);
				}
			}
			if (view instanceof TableRow)
			{
				for (int i = 0; i < 3; i++)
				{
					Button mtemp = (Button) ((ViewGroup) view).getChildAt(i);
					mtemp.setEnabled(true);
				}
			}
		}
	};
	
	public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		switch (requestCode)
			{
				case REQUEST_CONNECT_DEVICE_SECURE:
					// When DeviceListActivity returns with a device to connect
					if (resultCode == Activity.RESULT_OK)
					{
						connectDevice(data, true);
					}
					break;
				case REQUEST_CONNECT_DEVICE_INSECURE:
					// When DeviceListActivity returns with a device to connect
					if (resultCode == Activity.RESULT_OK)
					{
						connectDevice(data, false);
					}
					break;
				case REQUEST_ENABLE_BT:
					// When the request to enable Bluetooth returns
					if (resultCode == Activity.RESULT_OK)
					{
						// Bluetooth is now enabled, so set up a chat session
						checkDiscoverable();
						setupChat();
					}
					else
					{
						// User did not enable Bluetooth or an error occurred
						Toast.makeText(this, R.string.bt_not_enabled_leaving,
								Toast.LENGTH_SHORT).show();
						finish();
					}
			}
	}
	
	private void connectDevice(Intent data, boolean secure)
	{
		// Get the device MAC address
		String address =
				data.getExtras().getString(
						DeviceListActivity.EXTRA_DEVICE_ADDRESS);
		// Get the BluetoothDevice object
		BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
		// Attempt to connect to the device
		mCallingDevice = mBluetoothAdapter.getName();
		TelephonyManager tManager =
				(TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		String uuid = tManager.getDeviceId();
		mChatService.connect(device, secure, uuid);
		mTurns.setText("Your Turn.");
		show();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.option_menu, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		Intent serverIntent = null;
		switch (item.getItemId())
			{
				case R.id.secure_connect_scan:
					// Launch the DeviceListActivity to see devices and do scan
					serverIntent = new Intent(this, DeviceListActivity.class);
					startActivityForResult(serverIntent,
							REQUEST_CONNECT_DEVICE_SECURE);
					return true;
					
				case R.id.discoverable:
					// Ensure this device is discoverable by others
					ensureDiscoverable();
					return true;
			}
		return false;
	}
	
	@Override
	public void onBackPressed()
	{
		dialog =
				new AlertDialog.Builder(TicTacToe.this)
						.create();
		dialog.setTitle("Tic Tac Toe");
		dialog.setMessage("Want to quit the game?");
		
		dialog.setButton(Dialog.BUTTON_POSITIVE,"OK",
				new DialogInterface.OnClickListener(){
					
					@Override
					public void onClick(DialogInterface dialog, int which)
					{
						sendMessage("finish");
						
						mPlayedScore.setText("" + 0);
						mWonScore.setText("" + 0);
						mLostScore.setText("" + 0);
						mDrawnScore.setText("" + 0);
						makeClearButtons(layout);
						ScorePlayed = 0;
						ScoreWon = 0;
						ScoreLost = 0;
						ScoreDrawn = 0;
						finish();

						dialog.dismiss();
					}
				});
		dialog.setButton(Dialog.BUTTON_NEGATIVE,"CANCEL",
				new DialogInterface.OnClickListener(){
					
					@Override
					public void onClick(DialogInterface dialog, int which)
					{
						dialog.dismiss();
					}
				});
		
		if(mresetFlag)
		{
			ScorePlayed = 0;
			ScoreWon = 0;
			ScoreLost = 0;
			ScoreDrawn = 0;
			
			for (int i = 0; i < 9; i++)
				mArray[i] = " ";
			
			mPlayedScore.setText(""
					+ ScorePlayed);
			mWonScore.setText("" + ScoreWon);
			mLostScore.setText("" + ScoreLost);
			mDrawnScore
					.setText("" + ScoreDrawn);
		}
		
		if(mConnectedFlag)
		{	dialog.show();
		}
		else
			finish();
	}
}
