package com.wli.tictactoe.activities;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.wli.tictactoe.application.TicTacToeConstants;
import com.wli.tictactoe.database.MyDBHelper;

/**
 * This class is used where options for game are selected. 
 *
 */

public class Main extends Activity
{
	private Button mStart, mOptions, mAboutUs, mHelp;
	private Intent mintent;
	BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
	Cursor mCursor;
	boolean mFlag = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		mStart = (Button)findViewById(R.id.rlbtnstart);
		mOptions = (Button)findViewById(R.id.rlbtnoptions);
		mAboutUs = (Button)findViewById(R.id.rlbtnaboutus);
		mHelp = (Button)findViewById(R.id.rlbtnhelp);
		
		mStart.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				
				MyDBHelper mhelper = new MyDBHelper(Main.this);
				mhelper.open();
				
				 mCursor = mhelper.getPlayerName();
				
				if(mCursor!=null)
				{
					if(mCursor.moveToFirst())
					{
						mintent = new Intent(Main.this,TicTacToe.class);
						mintent.putExtra("sPlayerName", mCursor.getString(0));
						startActivityForResult(mintent,0);
					}
					else
					{
						mintent = new Intent(Main.this,PlayerName.class);
						startActivity(mintent);
					}
				}else
				{
					mintent = new Intent(Main.this,PlayerName.class);
					startActivity(mintent);
				}
				
			}
		});
		
		mOptions.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				
				mintent = new Intent(Main.this, Options.class);
				startActivity(mintent);
			}
		});
		
		mAboutUs.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				
				mintent = new Intent(Main.this, AboutUsHelp.class);
				mintent.putExtra("page", "about.html");
				startActivity(mintent);
			}
		});
		
		mHelp.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				
				mintent = new Intent(Main.this, AboutUsHelp.class);
				mintent.putExtra("page", "help.html");
				startActivity(mintent);
			}
		});
		
	}

	/**
	 * This method plays sound for button click.
	 */
	public void playButton()
	{
		MediaPlayer m = new MediaPlayer();
		try
		{
			AssetFileDescriptor descriptor =
					Main.this.getAssets().openFd("btnClick.caf");
			m.setDataSource(descriptor.getFileDescriptor(),
					descriptor.getStartOffset(), descriptor.getLength());
			descriptor.close();
			m.prepare();
			m.start();
		}
		catch (Exception e)
		{
			// handle error here..
			Log.e("Error in Sound", "" + e);
		}
	}
	
	@Override
	protected void onDestroy()
	{
		super.onDestroy();
			mBluetoothAdapter.disable();
		if(mCursor!=null)
			mCursor.close();
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		
		switch (requestCode)
		{
			case 0:
				if (resultCode == RESULT_OK)
				{
					finish();
				}
				if(resultCode == 1)
				{
					mFlag = true;
					finish();
				}
				break;
		}
	}
	
}
