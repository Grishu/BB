package com.wli.tictactoe.activities;

import com.wli.tictactoe.application.TicTacToeConstants;

import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * This class shows the different options for the game. 
 *
 */

public class Options extends Activity
{
	TextView mgmrltvGameSettings, mgmrltvContactus, mgmrltvOtherApp, mgmrltvheading;
	Intent mintent;
	Button mgmrloptionsbtnback;
	RelativeLayout mrlrow1, mrlrow2, mrlrow3;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.options);

		Typeface face=Typeface.createFromAsset(getAssets(), "AACHENN_0.TTF"); 
		
		mgmrltvGameSettings = (TextView)findViewById(R.id.gmrltvGameSettings);
		mgmrltvContactus = (TextView)findViewById(R.id.gmrltvContactus);
		mgmrltvOtherApp = (TextView)findViewById(R.id.gmrltvOtherApp);
		mgmrltvheading = (TextView)findViewById(R.id.gmrltvheading);
		
		mgmrloptionsbtnback = (Button)findViewById(R.id.gmrloptionsbtnback);
		mrlrow1 = (RelativeLayout)findViewById(R.id.rlrow1);
		mrlrow2 = (RelativeLayout)findViewById(R.id.rlrow2);
		mrlrow3 = (RelativeLayout)findViewById(R.id.rlrow3);
		
		mgmrltvheading.setTextSize(30);
		mgmrltvheading.setTypeface(face);
		mgmrltvGameSettings.setTypeface(face);
		mgmrltvContactus.setTypeface(face);
		mgmrltvOtherApp.setTypeface(face);
		
		mrlrow1.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				
				mintent = new Intent(Options.this, Settings.class);
				startActivity(mintent);
			}
		});
		
		mrlrow2.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				
				mintent = new Intent(Options.this, ContactUs.class);
				startActivity(mintent);
			}
		});
		
		mrlrow3.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				
				mintent = new Intent(Options.this, OtherApps.class);
				startActivity(mintent);
			}
		});
		
		mgmrloptionsbtnback.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				
				finish();
			}
		});
	}
	
	/**
	 * This method plays sound for button click.
	 */
	public void playButton()
	{
		MediaPlayer m = new MediaPlayer();
		try
		{
			AssetFileDescriptor descriptor =
					Options.this.getAssets().openFd("btnClick.caf");
			m.setDataSource(descriptor.getFileDescriptor(),
					descriptor.getStartOffset(), descriptor.getLength());
			descriptor.close();
			m.prepare();
			m.start();
		}
		catch (Exception e)
		{
			// handle error here..
			Log.e("Error in Sound", "" + e);
		}
	}
}
