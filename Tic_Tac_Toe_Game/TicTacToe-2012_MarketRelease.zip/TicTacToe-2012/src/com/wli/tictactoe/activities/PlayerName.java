package com.wli.tictactoe.activities;

import com.wli.tictactoe.application.TicTacToeConstants;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

/**
 * This class is opened as Pop Up(Dialog) activity, which takes player name.
 *
 */

public class PlayerName extends Activity
{
	EditText mplayerName;
	Button msubmit;
	AlertDialog dialog;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE); 
		setContentView(R.layout.player_name);

		mplayerName = (EditText)findViewById(R.id.rledtPlayername);
		msubmit = (Button)findViewById(R.id.rlbtnSubmit);
		
		msubmit.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				if(checkEntryForEmpty(mplayerName.getText().toString()))
				{
					dialog = new AlertDialog.Builder(PlayerName.this).create();
					dialog.setTitle("Tic Tac Toe");
					dialog.setMessage("Player Name can not be empty.");
					
					dialog.setButton(Dialog.BUTTON_POSITIVE,"OK", new DialogInterface.OnClickListener(){
						
						@Override
						public void onClick(DialogInterface dialog, int which)
						{
							dialog.dismiss();
						}
					});
					dialog.show();
					return;
				}
				else
				{
					Intent mIntent = new Intent(PlayerName.this, TicTacToe.class);
					mIntent.putExtra("sPlayerName", mplayerName.getText().toString());
					
					startActivity(mIntent);
					finish();
				}
				
			}
		});
	}
	
	/**
	 * This method plays sound for button click.
	 */
	
	public void playButton()
	{
		MediaPlayer m = new MediaPlayer();
		try
		{
			AssetFileDescriptor descriptor =
					PlayerName.this.getAssets().openFd("btnClick.caf");
			m.setDataSource(descriptor.getFileDescriptor(),
					descriptor.getStartOffset(), descriptor.getLength());
			descriptor.close();
			m.prepare();
			m.start();
		}
		catch (Exception e)
		{
			// handle error here..
			Log.e("Error in Sound", "" + e);
		}
	}
	/**
	 * This method takes string value.
	 * @param p_entryValue
	 * @return true or flase.
	 */
	 public static boolean checkEntryForEmpty(String p_entryValue)
		{
			String m_entryName = p_entryValue.trim();
			
			if((m_entryName.toString().equalsIgnoreCase("")) || (m_entryName.toString().length() <= 0))
			{
				return true;
			}
			
			return false;
		}

}
