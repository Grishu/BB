/**
 *	Project Name   :   Ecard
 *  Class Name     :   ContactUs
 *  Description    :   Activity send feedback and contact us by this screen
 *  Author         :   weblineIndia
 *  Creation Date  :   
 *  Modify Date    :   
 */
package com.wli.tictactoe.activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.location.LocationManager;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

/**
 * This class is used as Contact Us to take feedback from users. 
 *
 */

public class ContactUs extends Activity
{
	public static TextView cs_category;
	private ImageButton cs_btn_back, cs_btn_send;
	private EditText cs_et_feedback, cs_et_userName;
	
	protected LocationManager locationManager;
	private String android_version, android_device_name, userFeedback, feedback_email, subject;
	private String device_os_name = "Android";
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.contactscreen);
		
		cs_category = (TextView)findViewById(R.id.cs_category);
		Typeface face=Typeface.createFromAsset(getAssets(), "AACHENN_0.TTF"); 
		cs_category.setTypeface(face);
		
		cs_btn_back = (ImageButton) findViewById(R.id.cs_btn_back);
		cs_btn_back.setOnClickListener(new btn_back_close_OnClickListner());
		
		cs_btn_send = (ImageButton) findViewById(R.id.cs_btn_send);
		cs_btn_send.setOnClickListener(new btn_back_close_OnClickListner());
		
		cs_et_feedback = (EditText) findViewById(R.id.cs_et_feedback);
		cs_et_userName = (EditText) findViewById(R.id.cs_et_userName);
		
		android_version = android.os.Build.VERSION.RELEASE;
		android_device_name = android.os.Build.MODEL;
		
		feedback_email = this.getString(R.string.feedbackMailAddress);
		subject = this.getString(R.string.feedbackMailSubject);
		
		cs_btn_back.setOnClickListener(new cs_btn_back_OnClickListner());
		cs_btn_send.setOnClickListener(new cs_btn_send_OnClickListner());
			
	}
	
	
	
	/**
	 * 	Listener for send feedback/contact us
	 */
	private class cs_btn_send_OnClickListner implements android.view.View.OnClickListener
	{
		@Override
		public void onClick(View v)
		{
			userFeedback = cs_et_feedback.getText().toString();
			
			Intent emailIntent = new Intent(Intent.ACTION_SEND);
			emailIntent.setType("image/png");
			emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[] { feedback_email });
			emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
			
			emailIntent.putExtra(Intent.EXTRA_TEXT, Html.fromHtml("<b>Your FeedBack:</b>" + "<br><br>" + userFeedback + "<br><br> Thanks, <br><br>" + cs_et_userName.getText().toString() + "<br><br><b><u>Device Information</u> :</b><br><br> <b>Device Name : </b>" + android_device_name + "." + "<br><b>Device OS & Version :</b> " + device_os_name + " " + android_version));
			
			startActivity(Intent.createChooser(emailIntent, "Send feedback"));
			
		}
	}
	
	
	/**
	 * 	Listener for finish activity
	 */
	private class cs_btn_back_OnClickListner implements android.view.View.OnClickListener
	{	
		@Override
		public void onClick(View v)
		{
			finish();
		}
	}
	
	

	/**
	 * 	Listener for finish activity
	 */
	private class btn_back_close_OnClickListner implements android.view.View.OnClickListener
	{
		@Override
		public void onClick(View v)
		{
			finish();
		}
	}
}
