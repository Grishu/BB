package com.wli.tictactoe.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.wli.tictactoe.application.TicTacToeConstants;
import com.wli.tictactoe.database.MyDBHelper;

/**
 * This class is used to edit player name, to change theme, and controlling sound. 
 *
 */

public class Settings extends Activity
{
	Button mbtnEdit, mTheme1, mTheme2, mTheme3, mBack;
	ToggleButton mSound;
	EditText medtPlayerName;
	AlertDialog dialog;
	Cursor mCursor;
	TextView mrltvSound, mrltvThemes, mrltveditPlayerName, mrltvSettings;
	MyDBHelper mDbHelper = new MyDBHelper(Settings.this);
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.settings);
		
		mbtnEdit = (Button) findViewById(R.id.rlbtnedit);
		mTheme1 = (Button) findViewById(R.id.rlbtntheme1);
		mTheme2 = (Button) findViewById(R.id.rlbtntheme2);
		mTheme3 = (Button) findViewById(R.id.rlbtntheme3);
		mSound = (ToggleButton) findViewById(R.id.rltogglebtn);
		mBack = (Button)findViewById(R.id.rloptionsbtnback);
		
		mrltvSound = (TextView)findViewById(R.id.rltvSound);
		mrltvThemes = (TextView)findViewById(R.id.rltvThemes);
		mrltveditPlayerName = (TextView)findViewById(R.id.rltveditPlayerName);
		mrltvSettings = (TextView)findViewById(R.id.rltvSettings);
		
		mSound.setText(" ");
		
		if(TicTacToeConstants.SOUND)
		{
			mSound.setChecked(true);
			mSound.setBackgroundResource(R.drawable.on);
			mSound.setText(" ");
		}
		
		medtPlayerName = (EditText) findViewById(R.id.rledtplayername);
		
		Typeface face=Typeface.createFromAsset(getAssets(), "AACHENN_0.TTF"); 
		mrltvSound.setTypeface(face);
		mrltvThemes.setTypeface(face);
		mrltveditPlayerName.setTypeface(face);
		mrltvSettings.setTypeface(face);
		mrltvSettings.setTextSize(30);
		
		mDbHelper.open();
		
		mCursor = mDbHelper.getPlayerName();
		
		if (mCursor != null)
		{
			if (mCursor.moveToFirst())
			{
				medtPlayerName.setText(mCursor.getString(0));
			}
		}
		if(mCursor!=null)
			mCursor.close();
		if(mDbHelper!=null)
			mDbHelper.close();
		
		mTheme1.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				TicTacToeConstants.THEME = R.style.Theme;
				TicTacToeConstants.ZEROP1 = R.drawable.zero1p1;
				TicTacToeConstants.CROSSP1 = R.drawable.cross1p1;
				TicTacToeConstants.ZEROP2 = R.drawable.zero1p2;
				TicTacToeConstants.CROSSP2 = R.drawable.cross1p2;
				TicTacToeConstants.SCORE_BACK = R.drawable.score_back;
				Toast.makeText(Settings.this,"Theme 1 is applied.", Toast.LENGTH_SHORT ).show();
				finish();
			}
		});
		
		mTheme2.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				TicTacToeConstants.THEME = R.style.Theme2;
				TicTacToeConstants.ZEROP1 = R.drawable.zero2p1;
				TicTacToeConstants.CROSSP1 = R.drawable.cross2p1;
				TicTacToeConstants.ZEROP2 = R.drawable.zero2p2;
				TicTacToeConstants.CROSSP2 = R.drawable.cross2p2;
				TicTacToeConstants.SCORE_BACK = R.drawable.score_back2;
				Toast.makeText(Settings.this,"Theme 2 is applied.",Toast.LENGTH_SHORT ).show();
				finish();
			}
		});
		
		mTheme3.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				TicTacToeConstants.THEME = R.style.Theme3;
				TicTacToeConstants.ZEROP1 = R.drawable.zero3p1;
				TicTacToeConstants.CROSSP1 = R.drawable.cross3p1;
				TicTacToeConstants.ZEROP2 = R.drawable.zero3p2;
				TicTacToeConstants.CROSSP2 = R.drawable.cross3p2;
				TicTacToeConstants.SCORE_BACK = R.drawable.score_back3;
				Toast.makeText(Settings.this,"Theme 3 is applied.",Toast.LENGTH_SHORT ).show();
				finish();
			}
		});
		
		mSound.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(mSound.getText().toString().equals("ON"))
				{
					TicTacToeConstants.SOUND = true;
					mSound.setChecked(true);
					playButton();
					mSound.setBackgroundResource(R.drawable.on);
					mSound.setText(" ");
				}
				else
				{
					TicTacToeConstants.SOUND = false;
					mSound.setBackgroundResource(R.drawable.off);
					mSound.setText(" ");
				}
			}
		});
		
		mbtnEdit.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				
				if (checkEntryForEmpty(medtPlayerName.getText().toString()))
				{
					dialog = new AlertDialog.Builder(Settings.this).create();
					dialog.setTitle("Tic Tac Toe");
					dialog.setMessage("Player Name can not be empty.");
					
					dialog.setButton(Dialog.BUTTON_POSITIVE, "OK",
							new DialogInterface.OnClickListener(){
								
								@Override
								public void onClick(DialogInterface dialog, int which)
								{
									dialog.dismiss();
								}
							});
					dialog.show();
					return;
				}
				
				mDbHelper.open();
				
				mCursor = mDbHelper.getPlayerName();
				
				if (mCursor != null)
				{
					if (mCursor.moveToFirst())
					{
						long id =
								mDbHelper.updatePlayerName(medtPlayerName
										.getText().toString(), mCursor
										.getString(0));
						if (id > 0)
						{
							dialog =
									new AlertDialog.Builder(Settings.this)
											.create();
							dialog.setTitle("Tic Tac Toe");
							dialog.setMessage("Updated Successfully.");
							
							dialog.setButton(Dialog.BUTTON_POSITIVE, "OK",
									new DialogInterface.OnClickListener(){
										
										@Override
										public void onClick(DialogInterface dialog, int which)
										{
											finish();
											dialog.dismiss();
										}
									});
							dialog.show();
						}
					}
					else
					{
						Toast.makeText(Settings.this, "There is no Player name entered in Data base.",Toast.LENGTH_SHORT ).show();
					}
				}
				
			}
		});
		
		mBack.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v)
			{
				if(TicTacToeConstants.SOUND)
					playButton();
				finish();
			}
		});
		
	}

	
	/**
	 * This method plays sound for button click.
	 */
	
	public void playButton()
	{
		MediaPlayer m = new MediaPlayer();
		try
		{
			AssetFileDescriptor descriptor =
					Settings.this.getAssets().openFd("btnClick.caf");
			m.setDataSource(descriptor.getFileDescriptor(),
					descriptor.getStartOffset(), descriptor.getLength());
			descriptor.close();
			m.prepare();
			m.start();
		}
		catch (Exception e)
		{
			// handle error here..
			Log.e("Error in Sound", "" + e);
		}
	}
	/**
	 * This method takes string value.
	 * @param p_entryValue
	 * @return true or flase.
	 */
	public static boolean checkEntryForEmpty(String p_entryValue)
	{
		String m_entryName = p_entryValue.trim();
		
		if ((m_entryName.toString().equalsIgnoreCase(""))
				|| (m_entryName.toString().length() <= 0))
		{
			return true;
		}
		
		return false;
	}
}
