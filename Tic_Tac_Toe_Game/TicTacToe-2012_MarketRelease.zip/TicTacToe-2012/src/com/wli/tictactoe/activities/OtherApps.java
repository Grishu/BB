package com.wli.tictactoe.activities;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

/**
 * This class opens webview for displaying other application by webline india. 
 *
 */

public class OtherApps extends Activity
{
	WebView mWebView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.other_apps);
		
		mWebView = (WebView)findViewById(R.id.other_app_webView);
		
		WebSettings m_set= mWebView.getSettings();
		if(m_set.supportZoom())
		m_set.setBuiltInZoomControls(true);
		mWebView.clearCache(true);
		mWebView.clearHistory();
		mWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		mWebView.loadUrl("http://www.ecards4i.com/o_apps/other-app.html");
	}
	
	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		mWebView = null;
	}
}
